# Justin Baum's 311 Project 4

## Compilation

```
make
```

or

```
gcc -std=c99 driver.c -o driverp4
```

## Purpose

These programs will all switch lowercase to uppercase and vice versa when run.

## Running

### For Subproject 1 program 1

```
./driverp4 1 file
```

### For Subproject 1 program 2

```
./driverp4 2 file
```

### For Subproject 1 program 3

```
./driverp4 3 file
```
